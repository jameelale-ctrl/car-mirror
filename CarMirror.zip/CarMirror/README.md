# Car Mirror

A sideloaded Android Auto app that mirrors your phone's screen onto the car display (e.g. Ford SYNC 4A) **while the car is parked**, with tap and swipe control from the car's touchscreen.

> Not for the Play Store: Google doesn't allow screen-mirroring apps on Android Auto. This is a personal, sideload-only build. Android Auto updates may break it.

## How it works

| Piece | What it does |
|---|---|
| `MainActivity` | Phone screen: starts/stops capture, opens tap-control setup |
| `MirrorService` | Foreground service holding the screen capture (`MediaProjection`) and a `VirtualDisplay` that mirrors the phone |
| `car/MirrorCarAppService` | Android Auto entry point (registered as a *navigation* app, the only type that gets a raw car surface) |
| `car/MirrorScreen` | Hands the car surface to the VirtualDisplay; forwards taps/scrolls; enforces parked-only |
| `car/PausedScreen` | Message shown on the car display whenever mirroring is blocked |
| `TouchService` | Accessibility service that turns car taps/swipes into phone touches |

**Parked-only rule:** the mirror shows only when the car reports a speed of ~0 for 2 seconds. If the car is moving, or doesn't report speed at all, the car display shows a "paused" message and the mirror is disconnected from the car surface.

## Build & install

1. Open the `CarMirror` folder in **Android Studio** (Ladybug or newer). Let it sync. It will generate the Gradle wrapper if asked.
2. Plug in your phone with **USB debugging** on and press **Run**, or use *Build → Build APK(s)* and install the APK.
   - Keep it a **debug** build. Release builds only accept official Android Auto hosts and need signing.

## Phone setup (one time)

1. **Enable Android Auto developer mode:** Settings → search "Android Auto" → scroll to *Version* → tap it 10 times → OK.
2. In Android Auto's **⋮ menu → Developer settings**, turn on **Unknown sources**. Without this, sideloaded apps don't appear on the car screen.
3. **Tap control:** open Car Mirror → *Set up tap control* → *Car Mirror tap control* → On.
   - If it's greyed out ("Restricted setting"), go to Settings → Apps → Car Mirror → **⋮ → Allow restricted settings**, then try again.
4. Android Auto launcher: if Car Mirror doesn't show on the car, check Android Auto → *Customise launcher* and tick it.

## Using it

1. On the phone, open Car Mirror → **Start mirroring** → choose **Entire screen** in the system prompt (Android 14+).
2. Connect to the Ranger (USB or wireless Android Auto).
3. On the SYNC screen, open **Car Mirror** from the Android Auto app list.
4. With the car stopped, your phone appears on the display. Tap or swipe on the SYNC screen to control it.
5. Stop with the **Stop** button on the car screen or the phone notification.

## Known limitations

- **Letterboxing:** a portrait phone shows as a centred strip on the wide car screen. Rotate the phone to landscape (with auto-rotate on) to fill more of the display.
- **Touch:** single taps and swipes only. No long-press, pinch, or multi-touch. Swipes start from the centre of the phone screen.
- **Speed data:** if Android Auto doesn't supply vehicle speed for your phone/car combo, mirroring stays paused. That's deliberate.
- **DRM/secure apps:** Netflix, banking apps etc. show black. Android blocks capturing them.
- **Lag:** expect some latency, especially over wireless Android Auto.
- **Android 14+:** the capture permission is asked each time you start mirroring. That's an OS rule.
- **Not compiled in the cloud:** this project was written without an Android SDK available, so the first Android Studio sync may flag minor fixes.
